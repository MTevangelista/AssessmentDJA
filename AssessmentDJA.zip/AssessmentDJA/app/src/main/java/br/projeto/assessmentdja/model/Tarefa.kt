package br.projeto.assessmentdja.model

class Tarefa (
    var descricao: String
)