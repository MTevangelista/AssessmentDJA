package br.projeto.assessmentdja.model

class Tarefas (
    var tarefa: List<Tarefa>
)