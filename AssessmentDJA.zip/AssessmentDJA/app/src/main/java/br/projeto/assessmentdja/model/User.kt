package br.projeto.assessmentdja.model

class User (
    var nome: String,
    var email: String,
    var senha: String,
    var CPF: String
    )